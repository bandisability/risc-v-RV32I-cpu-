# RV32I 指令集的 CPU 实现

## 闲言碎语

### 关于 RISC-V 指令集，又称“为什么 RISC-V 是神”

- 32 位架构，一个字为 32 位宽。
- 每一条指令都是 **32 位**（4 字节），每一条指令都接受 **3 个参数** （如 `add x1, x2, x3`），
  每一条指令的 opcode=ins\[6:0\], rd=ins\[11:7\], funct3=ins\[14:12\], rs1=ins\[19:15\], rs2=ins\[24:20], funct7=ins\[31:25\].
  只要一条指令有这个部分，位置就 **永远** 不会变（imm 是个例外，因为固定格式与固定 32 位长的 **折中**），这就是设计原则之 **简单源于规整**。
- 32 个 32 位寄存器，所以每个寄存器可以用 5bit 索引，如寄存器 `x17` 计作 `10001`.
- **更少则更快**。为您拍上一张 RV32I 的核心指令格式与基础整数指令集：
![核心指令格式](./core_instruction_format.png)
![基础整数指令集](./base_integer_instructions.png)

Exactly!
  
你已经学会 RISC-V 了，现在就来实现指令集吧！

## 具体实现

RISC-V 核心子集：

- 存储器访问指令 `lw`(load word), `sw`(store word)
- ALU 操作指令 `add`,`sub`, `and`, `or`
- 跳转指令 `beq`

实际实现：

- 10 条 R 类指令
- 9 条 I 类指令
- 5 条存储指令
- 6 条跳转指令
  共 30 条指令。

CPU 及其相关器件：

- `PC`，找下一条指令
- `ROM`，其实是指令存储器，或者是代码段内存，地址到指令的转换，加电启动的 BIOS。用一个写死的 `ROM` 实现
- `ID`，译码。然而由于 RISC-V 的 **简单规整**，ID只要分派指令位就好。
- `CU`，控制中心。从指令输入产生所有控制信号。有附属的 `aluctrl` 和 `ramctrl`.
- `Reg`，寄存器堆
- `ALU`，计算部件
- `RAM`，内存，实现时保证可写与可读

小部件：

- `Add`，使用 `ALU` 做+4。
- `MUX`，多路复用。
- `ImmGen`，接受完整指令，输出其中的立即数。

单周期实现流程如下：

- PC 更新。
注意到无论如何要得到新的 PC 值都需要过一遍 ROM，判断是不是是跳转指令。
同理，计算结果必须由 ALU 给出，PC+4 或是跳转。
PC 的数据通路循环：

```c
PC-->ROM-->ALU
 \<---------/
```

- R 类指令。
操作数全为寄存器，寄存器的值用于ALU，结果写回寄存器。

```c
ROM-->Reg(rs1)-->ALU-->Reg(rd)
  |-->Reg(rs2)-->|
```

- I 类指令。
操作数有一个立即数，寄存器的值用于ALU，结果写回寄存器。

```c
      Reg(rd)<-------\
ROM-->Reg(rs1)-->ALU--*
Imm------------->|
```

如果还要到内存里取数据，就会非常漫长，一直走到写回。

```c
      Reg(rd)<---------RAM(mdata)
ROM-->Reg(rs1)-->ALU-->RAM(maddr)
Imm------------->|
```

- S 类指令。
立即数与两个目标寄存器

```c
      Reg(rs1)-------->RAM(mdata)
ROM-->Reg(rs2)-->ALU-->RAM(maddr)
Imm------------->|
```

- B 类指令。

```c
PC---Add-------------->|
Imm------------->ALU-->MUX-->PC
             PC--/      /
                       /
ROM-->Reg(rs1)-->ALU--zflag
  |-->Reg(rs2)-->|
```
## 流水线实现


## 参考资料

Computer Organization and Design: The Hardware/Software interface, RISC-V Edition

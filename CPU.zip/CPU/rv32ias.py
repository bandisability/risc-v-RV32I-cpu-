i=0
s=''
que=[]
while True:
    s=input()
    if s=="EOF":
        break
    que.append("32'h%x: ins=32'h%s;"%(i,s))
    i+=4

for line in que:
    print(line)